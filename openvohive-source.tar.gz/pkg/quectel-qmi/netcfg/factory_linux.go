//go:build linux
// +build linux

package netcfg

// GetPlatformConfigurator returns the platform configurator
// GetPlatformConfigurator 返回平台配置器
func GetPlatformConfigurator() NetworkConfigurator {
	// OpenWrt 上把 L3 交给 netifd 接管（路由/DNS/NAT 由 OpenWrt 管理），
	// 其余 Linux 发行版仍走原生 netlink。
	if IsOpenWrt() {
		return NewOpenWrtConfigurator()
	}
	return NewLinuxConfigurator()
}
